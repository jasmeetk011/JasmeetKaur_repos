# Third party notices

## nunit.framework.csproj

| Reference                                   | Version         | License Type | License                                       |
|------------------------------------------------------------------------------------------------------------------------------|
| IsExternalInit                              | 1.0.3           | MIT          | https://licenses.nuget.org/MIT                |
| Microsoft.Win32.Registry                    | 5.0.0           | MIT          | https://licenses.nuget.org/MIT                |
| Nullable                                    | 1.3.1           | MIT          | https://licenses.nuget.org/MIT                |
| System.Runtime.Loader                       | 4.3.0           | MS-EULA      | http://go.microsoft.com/fwlink/?LinkId=329770 |
| TunnelVisionLabs.ReferenceAssemblyAnnotator | 1.0.0-alpha.160 | MIT          | https://licenses.nuget.org/MIT                |

## nunit.framework.legacy.csproj

| Reference                                   | Version         | License Type | License                        |
|---------------------------------------------------------------------------------------------------------------|
| IsExternalInit                              | 1.0.3           | MIT          | https://licenses.nuget.org/MIT |
| Nullable                                    | 1.3.1           | MIT          | https://licenses.nuget.org/MIT |
| TunnelVisionLabs.ReferenceAssemblyAnnotator | 1.0.0-alpha.160 | MIT          | https://licenses.nuget.org/MIT |
